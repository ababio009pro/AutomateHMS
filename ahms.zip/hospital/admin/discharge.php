<?php
session_start();
//error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
echo $id=$_GET['id'];// get doctor id


$sql=mysqli_query($conn,"UPDATE users SET ward='', room='' WHERE id='$id'");
if($sql)
{
    echo "<script>alert('patient discharge Successfully');</script>";
    header("location: manage-users.php");
}
?>