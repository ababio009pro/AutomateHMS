<?php
session_start();
//error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
echo $id=$_GET['id'];// get doctor id


$sql=mysqli_query($conn,"UPDATE appointment SET status='1' WHERE id='$id'");
if($sql)
{
    echo "<script>alert(' Successfully');</script>";
    header("location: appointment-history.php");
}
?>